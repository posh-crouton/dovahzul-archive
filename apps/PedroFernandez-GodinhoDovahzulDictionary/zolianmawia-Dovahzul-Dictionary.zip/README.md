Dovahzul-Dictionary
===================

This android application is a complete dictionary to the dragon's language in The Elder Scrolls: Skyrim. The application works offline. The dictionary is powered kindly by http://thuum.org/
